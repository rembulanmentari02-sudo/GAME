# ==========================================
# 1. DEKLARASI KARAKTER & WARNA TEKS
# ==========================================
define dani = Character('Dani', color="#3498db")
define rio = Character('Rio', color="#e74c3c")
define salsa = Character('Salsa', color="#9b59b6")
define nurul = Character('Nurul', color="#2ecc71")
define bu_rani = Character('Bu Rani', color="#f1c40f")
define n = Character(None, what_italic=True) # Untuk Narator/Suara Hati

# ==========================================
# 2. DEKLARASI ASET GAMBAR (BACKGROUND & KARAKTER)
# ==========================================
# Background (BG)
image bg kantin = "bg/kantin_sekolah.png"
image bg kelas = "bg/ruang_kelas.png"
image bg lorong = "bg/lorong_sekolah.png"
image bg hitam = "bg/hitam_pekat.png"
image bg ruang1 = "bg/ruang1.png"
image bg ruang2 = "bg/ruang2.png"
image bg ruang3 = "bg/ruang3.png"
image bg ruang4 = "bg/ruang4.png"
image bg transisi = "bg/transisi.png"

# Ekspresi Dani (Korban)
image dani biasa = "dani/dani_biasa.png"
image dani harap = "dani/dani_harap.png"
image dani sedih = "dani/dani_sedih.png"
image dani nangis = "dani/dani_nangis.png"
image dani takut = "dani/dani_takut.png"
image dani tunduk = "dani/dani_tunduk.png"
image dani kaget = "dani/dani_kaget.png"
image dani lega = "dani/dani_lega.png"
image dani senyum = "dani/dani_senyum.png"
image dani murung = "dani/dani_murung.png"
image dani hancur = "dani/dani_hancur.png"
image dani trauma = "dani/dani_trauma.png"

# Ekspresi Rio (Pelaku)
image rio biasa = "rio/rio_biasa.png"
image rio sinis = "rio/rio_sinis.png"
image rio tawa = "rio/rio_tawa.png"
image rio marah = "rio/rio_marah.png"
image rio ngejek = "rio/rio_ngejek.png"
image rio angkuh = "rio/rio_angkuh.png"
image rio kaget = "rio/rio_kaget.png"
image rio tunduk = "rio/rio_tunduk.png"
image rio sesal = "rio/rio_sesal.png"
image rio dorong = "rio/rio_dorong.png"
image rio ancam = "rio/rio_ancam.png"
image rio bosan = "rio/rio_bosan.png"

# Ekspresi Nurul (Teman/Saksi)
image nurul biasa = "nurul/nurul_biasa.png"
image nurul khawatir = "nurul/nurul_khawatir.png"
image nurul sedih = "nurul/nurul_sedih.png"
image nurul tegas = "nurul/nurul_tegas.png"
image nurul takut = "nurul/nurul_takut.png"
image nurul ragu = "nurul/nurul_ragu.png"
image nurul senyum = "nurul/nurul_senyum.png"
image nurul lega = "nurul/nurul_lega.png"

# Ekspresi Salsa (Teman/Bystander)
image salsa biasa = "salsa/salsa_biasa.png"
image salsa tawa = "salsa/salsa_tawa.png"
image salsa sinis = "salsa/salsa_sinis.png"
image salsa tegas = "salsa/salsa_tegas.png"
image salsa kaget = "salsa/salsa_kaget.png"

# Ekspresi Bu Rani (Guru)
image guru biasa = "guru/guru_biasa.png"
image guru senyum = "guru/guru_senyum.png"
image guru tegas = "guru/guru_tegas.png"
image guru marah = "guru/guru_marah.png"
image guru nasehat = "guru/guru_nasehat.png"
image guru heran = "guru/guru_heran.png"
image guru kaget = "guru/guru_kaget.png"

# ==========================================
# 3. DEKLARASI AUDIO (BGM & SFX)
# ==========================================
define audio.bgm_sekolah = "audio/bgm/cheerful_school.mp3"
define audio.bgm_tegang = "audio/bgm/tense_bullying.mp3"
define audio.bgm_sedih = "audio/bgm/sad_piano.mp3"
define audio.bgm_haru = "audio/bgm/warm_hopeful.mp3"

define audio.sfx_keramaian = "audio/sfx/kantin_crowd.mp3"
define audio.sfx_senggol = "audio/sfx/bump.mp3"
define audio.sfx_jatuh = "audio/sfx/body_fall.mp3"
define audio.sfx_bel = "audio/sfx/school_bell.mp3"
define audio.sfx_langkah = "audio/sfx/footsteps.mp3"
define audio.sfx_detak = "audio/sfx/heartbeat.mp3"
define audio.sfx_kaget = "audio/sfx/surprise.mp3"

define audio.vo_dani01 = "audio/vo/dani/dani01.mp3"
define audio.vo_dani02 = "audio/vo/dani/dani02.mp3"
define audio.vo_dani03 = "audio/vo/dani/dani03.mp3"
define audio.vo_dani04 = "audio/vo/dani/dani04.mp3"
define audio.vo_dani05 = "audio/vo/dani/dani05.mp3"

define audio.vo_rio01 = "audio/vo/rio/rio01.mp3"
define audio.vo_rio02 = "audio/vo/rio/rio02.mp3"
define audio.vo_rio03 = "audio/vo/rio/rio03.mp3"
define audio.vo_rio04 = "audio/vo/rio/rio04.mp3"
define audio.vo_rio05 = "audio/vo/rio/rio05.mp3"
define audio.vo_rio06 = "audio/vo/rio/rio06.mp3"
define audio.vo_rio07 = "audio/vo/rio/rio07.mp3"
define audio.vo_rio08 = "audio/vo/rio/rio08.mp3"
define audio.vo_rio09 = "audio/vo/rio/rio09.mp3"
define audio.vo_rio010 = "audio/vo/rio/rio010.mp3"

define audio.vo_nurul01 = "audio/vo/nurul/nurul01.mp3" 
define audio.vo_nurul02 = "audio/vo/nurul/nurul02.mp3" 
define audio.vo_nurul03 = "audio/vo/nurul/nurul03.mp3" 
define audio.vo_nurul04 = "audio/vo/nurul/nurul04.mp3" 
define audio.vo_nurul05 = "audio/vo/nurul/nurul05.mp3" 
define audio.vo_nurul06 = "audio/vo/nurul/nurul06.mp3" 
define audio.vo_nurul07 = "audio/vo/nurul/nurul07.mp3" 
define audio.vo_nurul08 = "audio/vo/nurul/nurul08.mp3" 

define audio.vo_salsa01 = "audio/vo/salsa/salsa01.mp3"
define audio.vo_salsa02 = "audio/vo/salsa/salsa02.mp3"
define audio.vo_salsa03 = "audio/vo/salsa/salsa03.mp3"

define audio.vo_guru01 = "audio/vo/guru/guru01.mp3"
define audio.vo_guru02 = "audio/vo/guru/guru02.mp3"
define audio.vo_guru03 = "audio/vo/guru/guru03.mp3"
define audio.vo_guru04 = "audio/vo/guru/guru04.mp3"
define audio.vo_guru05 = "audio/vo/guru/guru05.mp3"
define audio.vo_guru06 = "audio/vo/guru/guru06.mp3"
define audio.vo_guru07 = "audio/vo/guru/guru07.mp3"
define audio.vo_guru08 = "audio/vo/guru/guru08.mp3"

# ==========================================
# 4. GAME DIMULAI (PROLOG)
# ==========================================
label start:
    play music bgm_sekolah fadein 2.0

    # SCENE 1
    scene bg ruang1 with fade
    play sound sfx_keramaian loop volume 0.5
    n "Waktu istirahat adalah saat yang ditunggu semua siswa."
    pause 0.5

    # SCENE 2
    scene bg ruang2 with dissolve
    n "Kantin sekolah penuh tawa dan antrean panjang."
    pause 0.5

    # SCENE 3
    play sound sfx_detak
    scene bg ruang3 with fade
    n "Tapi, bagi Dani …."
    pause 0.5

    # SCENE 4
    play sound sfx_kaget
    scene bg ruang4 with dissolve
    n "Antrean bukan hanya soal beli makanan, melainkan tentang menahan rasa malu."
    pause 0.5

    # TRANSISI KE CERITA UTAMA
    scene bg transisi with fade
    n "Hari ini, satu kejadian kecil di kantin akan menentukan segalanya."
    pause 1.0

# ==========================================
# ADEGAN 1: KANTIN
# ==========================================
label adegan_kantin:
    scene bg kantin with dissolve
    play sound sfx_keramaian loop volume 0.5
    
    n "Anak-anak berbaris rapi didepan kantin." # [cite: 12]
    
    show dani harap at center with easeinleft
    play sound audio.vo_dani01
    dani "Semoga masih ada roti." # [cite: 13]
    
    play sound sfx_senggol
    show dani kaget at left with vpunch
    show rio dorong at right with easeinright
    play music bgm_tegang fadeout 1.0
    
    play sound audio.vo_rio01
    rio "Eh gendut! Lama banget sih jalannya." # [cite: 14]
    
    show dani takut
    show rio sinis
    play sound audio.vo_dani02
    dani "Jangan ejek aku Rio!" # [cite: 15]
    
    show rio tawa
    play sound audio.vo_rio02
    rio "Hahaha, antre kayak kura-kura, pantes ga kebagian." # [cite: 16]
    hide rio with dissolve
    hide dani with dissolve
    
    show salsa biasa at center with easeinleft
    n "Salsa melihat kejadian Dani diperlakukan begitu oleh Rio." # [cite: 17]

    # PILIHAN 1: SALSA
    n "Melihat hal tersebut apa yang sebaiknya Salsa lakukan?" # [cite: 18]
    menu:
        "Membela Dani dengan tegas": # [cite: 21]
            jump salsa_membela
            
        "Ikut membully dan menertawakan Dani": # [cite: 19]
            jump salsa_membully

label salsa_membela:
    show salsa tegas
    play sound audio.vo_salsa01
    salsa "Hentikan Rio, kamu tidak boleh mengejek Dani seperti itu." # [cite: 24]
    hide salsa with dissolve

    show rio sinis
    play sound audio.vo_rio03
    rio "Halah, bercanda doang kok." # [cite: 25]
    hide rio with dissolve
    
    show salsa tegas
    play sound audio.vo_salsa02
    salsa "Kalau Dani sedih, artinya bukan bercanda dong, melainkan kamu sedang membully dia." # [cite: 26]
    hide salsa with dissolve
    
    show rio bosan
    play sound audio.vo_rio04
    rio "Masa sih, ah kamu gak seru!" # [cite: 27]
    $ karma_rio = -1
    jump adegan_kelas

label salsa_membully:
    show salsa tawa
    play sound audio.vo_salsa03
    salsa "Iya nih, lama banget, dasar gendut! Hahaha" # [cite: 29]
    hide salsa with dissolve
    
    show rio dorong
    play sound sfx_jatuh
    show dani hancur at left with hpunch
    play sound audio.vo_rio05
    rio "Hahaha, minggir dong" # [cite: 30]
    
    n "Rio mendorong tubuh Dani sampai jatuh." # [cite: 30]
    
    hide dani with easeoutleft
    n "Dani keluar dari antrean dengan perasaan sedih." # [cite: 31]
    $ karma_rio = 1
    jump adegan_kelas

# ==========================================
# ADEGAN 2: KELAS
# ==========================================
label adegan_kelas:
    stop sound fadeout 2.0
    scene bg hitam with dissolve
    play sound sfx_bel
    pause 2.0
    
    scene bg kelas with dissolve
    play music bgm_sedih fadein 1.0
    
    n "Setelah waktu istirahat berakhir, siswa siswi Kembali memasuki kelas mereka masing-masing. Dani nampak sedih dan berlinang airmata." # [cite: 32]
    
    show dani nangis at left
    show nurul khawatir at right with easeinright
    
    play sound audio.vo_nurul01
    nurul "Kamu kenapa Dani? Kok kayak sedih banget gitu" # [cite: 33]
    
    # PILIHAN 2: DANI
    n "Apa yang seharusnya dilakukan Dani?" # [cite: 34]
    menu:
        "Menceritakan apa yang dia alami": # [cite: 37]
            jump dani_cerita
            
        "Diam saja": # [cite: 35]
            jump dani_diam

label dani_cerita:
    show dani sedih
    play sound audio.vo_dani03
    dani "Tadi di kantin Rio membullyku, dia ngatain aku gendut dan lambat kaya kura-kura. Aku sedih." # [cite: 40]
    
    show nurul senyum
    play sound audio.vo_nurul02
    nurul "Sabar ya Dani, jangan pedulikan apa yang dikatakan Rio. Kamu berteman saja dengan teman-teman yang mau berteman sama kamu" # [cite: 41]
    
    show dani senyum
    play sound audio.vo_dani04
    dani "Iya Nurul, terima kasih" # [cite: 42]
    jump rio_masuk_kelas
    hide dani

label dani_diam:
    show dani murung
    n "Dani hanya terdiam dan menggeleng pelan, menyimpan rasa sakitnya sendirian."
    jump rio_masuk_kelas

label rio_masuk_kelas:
    play sound sfx_langkah
    show rio angkuh at center with easeinright
    show dani takut
    show nurul biasa at right
    
    play sound audio.vo_rio06
    rio "Eh gendut, kamu nangis ya? Cengeng banget sih." # [cite: 44]
    
    show nurul tegas
    play sound audio.vo_nurul03
    nurul "Kamu jangan gitu Rio, gara-gara kamu Dani jadi sedih." # [cite: 45]
    
    show rio ancam
    play sound audio.vo_rio07
    rio "Heh, jangan ikut campur ya. Awas lo!" # [cite: 46]
    
    show nurul takut
    n "Sikap Nurul sebaiknya setelah ini?" # [cite: 47]
    menu:
        "Melaporkan kepada guru": # [cite: 50]
            $ nurul_berani = True
        "Diam saja": # [cite: 48]
            $ nurul_berani = False

# ==========================================
# ADEGAN 3: PELAJARAN BU RANI
# ==========================================
label adegan_pelajaran:
    hide rio
    hide dani
    hide nurul
    
    show guru biasa at center with dissolve
    n "Beberapa saat kemudian, Ibu Rani (wali kelas 5B) memasuki ruang kelas." # [cite: 52]
    
    show guru nasehat
    play sound audio.vo_guru01
    bu_rani "Anak-anak, hari ini ibu akan memaparkan tentang bully. Kalian tau, bully itu perbuatan yang tidak baik dan merugikan. Baik bagi pelaku dan korban" # [cite: 53]
    
    show nurul ragu at right with easeinright
    play sound audio.vo_nurul04
    nurul "Bu Rani, kalau mengejek teman itu termasuk bully ya?" # [cite: 54]
    
    show guru senyum
    play sound audio.vo_guru02
    bu_rani "Betul Nurul, bullying itu ada macam-macam jenisnya. Ada bullying verbal, fisik, dan media social. Mengejek teman, itu termasuk bullying verbal." # [cite: 55]
    
    show guru heran
    play sound audio.vo_guru03
    bu_rani "Apakah Nurul pernah mengalaminya atau pernah melihat peristiwa bullying ?" # [cite: 55]
    
    show nurul khawatir
    play sound audio.vo_nurul05
    nurul "Hhhmmmm….." # [cite: 56]
    n "Perasaannya campur aduk, seakan ragu untuk mengatakan." # [cite: 56]

    # PILIHAN 3: NURUL
    n "Jika kamu diposisi Nurul, apa yang harus kamu lakukan?" # [cite: 57]
    menu:
        "Berkata Jujur": # [cite: 60]
            jump nurul_jujur
            
        "Berbohong": # [cite: 58]
            jump nurul_bohong

label nurul_jujur:
    show nurul tegas
    play sound audio.vo_nurul06
    nurul "Tadi Dani cerita bu, Dia di ejek saat antri dikantin" # [cite: 63]
    
    show guru kaget
    play sound audio.vo_guru04
    bu_rani "Benarkah Nurul, Siapa yang mengejek Dani?" # [cite: 64]
    show guru biasa

    play sound audio.vo_nurul07
    nurul "Rio, bu" # [cite: 65]
    
    show rio kaget at left with easeinleft
    show guru tegas
    play sound audio.vo_guru05
    bu_rani "Apakah benar yang dikatakan Nurul, Rio?" # [cite: 66]
    
    show rio tunduk
    play sound audio.vo_rio08
    rio "Iya, bu guru..." # [cite: 67]
    n "Rio menundukkan kepalanya." # [cite: 67]
    jump resolusi

label nurul_bohong:
    show nurul takut
    play sound audio.vo_nurul08 
    nurul "Tidak bu, tidak pernah." # [cite: 69]
    n "Nurul menatap Rio dengan perasaan takut." # [cite: 69]
    show rio sinis at left with easeinleft
    jump resolusi

# ==========================================
# ADEGAN 4: RESOLUSI & ENDING
# ==========================================
label resolusi:
    hide nurul
    show guru nasehat at right
    
    play sound audio.vo_guru06 
    bu_rani "Agama mengajarkan kita untuk senantiasa menjaga lisan." # [cite: 70]
    
    play sound audio.vo_guru07
    bu_rani "Menyakiti teman adalah perbuatan yang tidak disukai Allah swt." # [cite: 71]

    # PILIHAN 4: RIO (PENENTU ENDING)
    n "Bagaimana reaksi Rio?"
    menu:
        "Meminta maaf": # [cite: 74]
            jump good_ending
            
        "Tidak peduli": # [cite: 72]
            jump bad_ending

label good_ending:
    play music bgm_haru fadein 2.0
    show rio sesal at left
    show dani biasa at center with dissolve
    
    play sound audio.vo_rio09
    rio "Maaf Dani… Selama ini aku salah." # [cite: 77]
    
    show dani lega
    play sound audio.vo_dani05
    dani "Iya, aku maafkan Rio. Tapi jangan di ulangi lagi ya." # [cite: 78]
    
    n "Mereka pun bersalam dan berpelukan." # [cite: 79]
    
    show guru senyum
    play sound audio.vo_guru08
    bu_rani "Nah, begitu dong. Berani untuk meminta maaf jika salah dan berbesar hati untuk memaafkan." # [cite: 80]
    
    scene bg hitam with dissolve
    n "Sejak saat itu Dani tidak takut lagi mengantri dan Rio pun belajar untuk mengendalikan diri." # [cite: 81]
    n "Kantin kembali menjadi tempat yang hangat bagi semua."
    
    show text "{size=100}GOOD ENDING{/size}" at truecenter with dissolve
    pause 3.0
    return

label bad_ending:
    play music bgm_sedih fadein 2.0
    show rio bosan at left
    
    play sound audio.vo_rio010
    rio "(Dalam hati) Ah, lebayyy." # [cite: 83]
    
    scene bg hitam with dissolve
    n "Sejak saat itu Dani tidak pernah kekantin lagi." # [cite: 84]
    
    show text "{size=50}Diam / tidak peduli saat melihat pembullyan\nberarti membiarkan luka tumbuh.{/size}" at truecenter with dissolve # [cite: 85]
    pause 4.0
    hide text with dissolve
    
    n "Kantin kembali ramai." # [cite: 86]
    n "Tapi, satu anak kehilangan senyum….." # [cite: 87]
    
    show text "{size=100}BAD ENDING{/size}" at truecenter with dissolve
    pause 3.0
    return